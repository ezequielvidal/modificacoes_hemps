#include "links.h"
#include "utils.h"

//inicializa pesos dos links com 0
//parametros: x, tamanho mpsoc em x
//parametros: y, tamanho mpsoc em y

void iniciarLinks(){
	for(int i=0; i<XDIM; i++){
		for(int j=0; j<YDIM; j++){
	    		if(i<XDIM-1){
		    		linkD[i][j]=0;
		    		linkE[i][j]=0;
		 	}
		 	if(j<YDIM-1){
		    		linkC[i][j]=0;
		    		linkB[i][j]=0;
		 	}
	      	}
	}
}

void printLinkC(){

	puts("\n");

	for(int i=0; i<XDIM; i++){
		for(int j=0; j<YDIM-1; j++){
			puts(" linkC "), puts(itoa(i)); puts("X"); puts(itoa(j)); puts(": "); puts(itoa(linkC[i][j]));
		}
		puts("\n");
	}
	puts("\n");
}

void printLinkB(){

	puts("\n");

	for(int i=0; i<XDIM; i++){
		for(int j=0; j<YDIM-1; j++){
			puts(" linkB "), puts(itoa(i)); puts("X"); puts(itoa(j)); puts(": "); puts(itoa(linkB[i][j]));
		}
		puts("\n");
	}
	puts("\n");
}

void printLinkD(){

	puts("\n");

	for(int i=0; i<XDIM-1; i++){
		for(int j=0; j<YDIM; j++){
			puts(" linkD "), puts(itoa(i)); puts("X"); puts(itoa(j)); puts(": "); puts(itoa(linkD[i][j]));
		}
		puts("\n");
	}
	puts("\n");
}

void printLinkE(){

	puts("\n");

	for(int i=0; i<XDIM-1; i++){
		for(int j=0; j<YDIM; j++){
			puts(" linkE "), puts(itoa(i)); puts("X"); puts(itoa(j)); puts(": "); puts(itoa(linkE[i][j]));
		}
		puts("\n");
	}
	puts("\n");
}

void printSomaLinks(){

	int soma=0;
	int somaC = 0;
	int somaB = 0;
	int somaD = 0;
	int somaE = 0;

	for(int i=0; i<XDIM; i++){
		for(int j=0; j<YDIM-1; j++){
			soma = soma + linkC[i][j] + linkB[i][j];
			somaC = somaC + linkC[i][j];
			somaB = somaB + linkB[i][j];
		}
	}
	putsv("soma dos linkC: ",somaC);
	putsv("soma dos linkB: ",somaB);

	for(int i=0; i<XDIM-1; i++){
		for(int j=0; j<YDIM; j++){
			soma = soma + linkD[i][j] + linkE[i][j];
			somaD = somaD + linkD[i][j];
			somaE = somaE + linkE[i][j];
		}
	}
	putsv("soma dos linkD: ",somaD);
	putsv("soma dos linkE: ",somaE);
	

	putsv("soma dos links: ",soma);
}


//adiciona pesos nos links
//parametros: xM, x da tarefa mestre
//parametros: yM, y da tarefa mestre
//parametros: xS, x da tarefa escrava
//parametros: yS, y da tarefa escrava

void adicionarPeso(int xM, int yM, int xS, int yS, int peso){
	
	if( xM < xS ){  //se o mestre esta a esquerda do escravo
		for(int i=xM; i<=xS; i++){

			if( i < xS){
				linkD[i][yM] = linkD[i][yM] + peso;
			} 		
		
			if( yM > yS ){  //se o mestre esta acima do escravo
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						linkB[i][j] = linkB[i][j] + peso;
					}
				}
			}
			if( yM < yS ){  //se o mestre esta abaixo do escravo
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						linkC[i][j] = linkC[i][j] + peso;
					}
				}
			}
			
		}
	}
	if( xM > xS ){  //se o mestre esta a direita do escravo
		for(int i=xM-1; i>=xS; i--){          //ver aqui xM-1, tava dando erro

			if( i >= xS){                                  
				linkE[i][yM] = linkE[i][yM] + peso;
			} 		
		
			if( yM > yS ){  //se o mestre esta acima do escravo
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						linkB[i][j] = linkB[i][j] + peso;
					}
				}
			}
			if( yM < yS ){  //se o mestre esta abaixo do escravo
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						linkC[i][j] = linkC[i][j] + peso;
					}
				}
			}
			
		}
	}
	if( xM == xS ){  //se o mestre esta no mesmo x do escravo, podendo estar acima ou embaixo
		

		if( yM > yS ){  //se o mestre esta acima do escravo
			for(int j=yM-1; j>=yS; j--){
					 
				linkB[xM][j] = linkB[xM][j] + peso;
			}
		}
		if( yM < yS ){  //se o mestre esta abaixo do escravo
			for(int j=yM; j<yS; j++){
						 
				linkC[xM][j] = linkC[xM][j] + peso;
			}
		}
			
		
	}
}


//remove pesos dos links
//parametros: xM, x da tarefa mestre
//parametros: yM, y da tarefa mestre
//parametros: xS, x da tarefa escrava
//parametros: yS, y da tarefa escrava

void removerPeso(int xM, int yM, int xS, int yS, int peso){
	
	if( xM < xS ){
		for(int i=xM; i<=xS; i++){

			if( i < xS){
				linkD[i][yM] = linkD[i][yM] - peso;
			} 		
		
			if( yM > yS ){
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						linkB[i][j] = linkB[i][j] - peso;
					}
				}
			}
			if( yM < yS ){
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						linkC[i][j] = linkC[i][j] - peso;
					}
				}
			}
			
		}
	}
	if( xM > xS ){
		for(int i=xM-1; i>=xS; i--){

			if( i >= xS){
				linkE[i][yM] = linkE[i][yM] - peso;
			} 		
		
			if( yM > yS ){
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						linkB[i][j] = linkB[i][j] - peso;
					}
				}
			}
			if( yM < yS ){
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						linkC[i][j] = linkC[i][j] - peso;
					}
				}
			}
			
		}
	}
	if( xM == xS ){  //se o mestre esta no mesmo x do escravo, podendo estar acima ou embaixo
		

		if( yM > yS ){  //se o mestre esta acima do escravo
			for(int j=yM-1; j>=yS; j--){
					 
				linkB[xM][j] = linkB[xM][j] - peso;
			}
		}
		if( yM < yS ){  //se o mestre esta abaixo do escravo
			for(int j=yM; j<yS; j++){
						 
				linkC[xM][j] = linkC[xM][j] - peso;
			}
		}
			
		
	}
}

//calcula o peso do caminho de um processador mestre a um processador escravo
//parametros: xM, x do processador mestre
//parametros: yM, y do processador mestre
//parametros: xS, x do processador escravo
//parametros: yS, y do processador escravo
//retona o peso do caminho

int calcularPeso(int xM, int yM, int xS, int yS){

	int pesoCaminho=0;	

	if( xM < xS ){
		for(int i=xM; i<=xS; i++){

			if( i < xS){
				pesoCaminho = pesoCaminho + linkD[i][yM];
			} 		
		
			if( yM > yS ){
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						pesoCaminho = pesoCaminho + linkB[i][j];
					}
				}
			}
			if( yM < yS ){
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						pesoCaminho = pesoCaminho + linkC[i][j];
					}
				}
			}
			
		}
	}
	if( xM > xS ){
		for(int i=xM-1; i>=xS; i--){

			if( i >= xS){
				pesoCaminho = pesoCaminho + linkE[i][yM];
			} 		
		
			if( yM > yS ){
				for(int j=yM-1; j>=yS; j--){
			
					if( i == xS ){
						 
						pesoCaminho = pesoCaminho + linkB[i][j];
					}
				}
			}
			if( yM < yS ){
				for(int j=yM; j<yS; j++){
			
					if( i == xS ){
						 
						pesoCaminho = pesoCaminho + linkC[i][j];
					}
				}
			}
			
		}
	}
	if( xM == xS ){  //se o mestre esta no mesmo x do escravo, podendo estar acima ou embaixo
		

		if( yM > yS ){  //se o mestre esta acima do escravo
			for(int j=yM-1; j>=yS; j--){
					 
				pesoCaminho = pesoCaminho + linkB[xM][j];
			}
		}
		if( yM < yS ){  //se o mestre esta abaixo do escravo
			for(int j=yM; j<yS; j++){
						 
				pesoCaminho = pesoCaminho + linkC[xM][j];
			}
		}
			
		
	}
	return pesoCaminho;

}

