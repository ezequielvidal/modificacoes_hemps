#ifndef LINKS_H_
#define LINKS_H_

#include "../../include/kernel_pkg.h"
#define XDIM XDIMENSION
#define YDIM YDIMENSION

//links

int linkD[XDIMENSION-1][YDIMENSION];   //   para a DIREITA
int linkE[XDIMENSION-1][YDIMENSION];   //   para a ESQUERDA
int linkC[XDIMENSION][YDIMENSION-1];   //   para CIMA
int linkB[XDIMENSION][YDIMENSION-1];   //   para BAIXO

//funcoes 

void iniciarLinks();//pode ser usado para remover todos os pesos
void adicionarPeso(int, int, int, int, int);
void removerPeso(int, int, int, int, int);
int calcularPeso(int, int, int, int);

void printLinkC();
void printLinkB();
void printLinkD();
void printLinkE();

void printSomaLinks();


#endif  /*LINKS_H_*/
