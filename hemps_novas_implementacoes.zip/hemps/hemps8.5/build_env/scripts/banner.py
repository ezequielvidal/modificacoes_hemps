#!/usr/bin/python

print"""

  _   _      __  __ ____  ____     ___   _____ 
 | | | | ___|  \//  |  _ \// ___|   ( _ ) |___ // 
 | |_| |// _ \ |\//| | |_) \___ \   // _ \   |_ \ 
 |  _  |  __// |  | |  __// ___) | | (_) | ___) |
 |_| |_|\___|_|  |_|_|   |____//   \___(_)____// 
                                               
                                                                                          
OBS:
\t1. Renaming local_scheduler   -> task_scheduler
\t\t1.a - Improvements on LST task scheduler to a better deadline miss monitoring
\t2. Renaming cluster_scheduler -> resource_manager
                            
"""

#fONTE Standard