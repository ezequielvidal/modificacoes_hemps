/*
 * prod_cons_std.h
 *
 *  Created on: 09/07/2016
 *      Author: ruaro
 */

#ifndef PROD_CONS_STD_H_
#define PROD_CONS_STD_H_


#define PROD_CONS_ITERATIONS	50



#endif /* PROD_CONS_STD_H_ */
