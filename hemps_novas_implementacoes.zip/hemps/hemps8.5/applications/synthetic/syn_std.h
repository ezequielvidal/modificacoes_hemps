/*
 * syn_std.h
 *
 *  Created on: 09/07/2016
 *      Author: ruaro
 */

#ifndef SYN_STD_H_
#define SYN_STD_H_


#define SYNTHETIC_ITERATIONS	10


#endif /* SYN_STD_H_ */
