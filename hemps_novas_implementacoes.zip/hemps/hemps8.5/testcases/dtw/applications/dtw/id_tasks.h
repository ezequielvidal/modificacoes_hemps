#define	p3	0
#define	p4	1
#define	p1	2
#define	recognizer	3
#define	bank	4
#define	p2	5
