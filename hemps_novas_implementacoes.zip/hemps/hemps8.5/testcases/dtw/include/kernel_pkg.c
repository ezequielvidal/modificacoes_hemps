#include "kernel_pkg.h"

ClusterInfo cluster_info[CLUSTER_NUMBER] = {
	{0, 0, 0, 0, 3, 3, 15},
};

