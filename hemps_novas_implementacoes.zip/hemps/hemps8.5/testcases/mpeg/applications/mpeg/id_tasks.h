#define	print	0
#define	start	1
#define	idct	2
#define	iquant	3
#define	ivlc	4
