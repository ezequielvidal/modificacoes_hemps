/*!\file resource_manager.c
 * HEMPS VERSION - 8.0 - support for RT applications
 *
 * Distribution:  June 2016
 *
 * Created by: Marcelo Ruaro - contact: marcelo.ruaro@acad.pucrs.br
 *
 * Research group: GAPH-PUCRS   -  contact:  fernando.moraes@pucrs.br
 *
 * \brief Selects where to execute a task and application
 * \detailed Cluster scheduler implements the cluster resources management,
 * task mapping, application mapping, and also can implement task migration heuristics.
 * Adittionally it have a function named: SearchCluster, which selects the cluster to send an application. This
 * function in only used in the global master mode
 */

#include "resource_manager.h"
#include "../../include/kernel_pkg.h"
#include "utils.h"
#include "processors.h"
#include "applications.h"
#include "links.h"

/** Allocate resources to a Cluster by decrementing the number of free resources. If the number of resources
 * is higher than free_resources, then free_resourcers receives zero, and the remaining of resources are allocated
 * by reclustering
 * \param cluster_index Index of cluster to allocate the resources
 * \param nro_resources Number of resource to allocated. Normally is the number of task of an application
 */
inline void allocate_cluster_resource(int cluster_index, int nro_resources){

	//puts(" Cluster address "); puts(itoh(cluster_info[cluster_index].master_x << 8 | cluster_info[cluster_index].master_y)); puts(" resources "); puts(itoa(cluster_info[cluster_index].free_resources));

	if (cluster_info[cluster_index].free_resources > nro_resources){
		cluster_info[cluster_index].free_resources -= nro_resources;
	} else {
		cluster_info[cluster_index].free_resources = 0;
	}

	//putsv(" ALLOCATE - nro resources : ", cluster_info[cluster_index].free_resources);
}

/** Release resources of a Cluster by incrementing the number of free resources according to the nro of resources
 * by reclustering
 * \param cluster_index Index of cluster to allocate the resources
 * \param nro_resources Number of resource to release. Normally is the number of task of an application
 */
inline void release_cluster_resources(int cluster_index, int nro_resources){

	//puts(" Cluster address "); puts(itoh(cluster_info[cluster_index].master_x << 8 | cluster_info[cluster_index].master_y)); puts(" resources "); puts(itoa(cluster_info[cluster_index].free_resources));

	cluster_info[cluster_index].free_resources += nro_resources;

   // putsv(" RELEASE - nro resources : ", cluster_info[cluster_index].free_resources);
}

/** This function is called by kernel manager inside it own code and in the modules: reclustering and cluster_scheduler.
 * It is called even when a task is mapped into a processor, by normal task mapping or reclustering.
 * Automatically, this function update the Processors structure by calling the add_task function
 * \param cluster_id Index of cluster to allocate the page
 * \param proc_address Address of the processor that is receiving the task
 * \param task_ID ID of the allocated task
 */
void page_used(int cluster_id, int proc_address, int task_ID){

	//puts("Page used proc: "); puts(itoh(proc_address)); putsv(" task id ", task_ID);
	add_task(proc_address, task_ID);

	allocate_cluster_resource(cluster_id, 1);
}

/** This function is called by manager inside it own code and in the modules: reclustering and cluster_scheduler.
 * It is called even when a task is removed from a processor.
 * Automatically, this function update the Processors structure by calling the remove_task function
 * \param cluster_id Index of cluster to remove the page
 * \param proc_address Address of the processor that is removing the task
 * \param task_ID ID of the removed task
 */
void page_released(int cluster_id, int proc_address, int task_ID){

	//puts("Page released proc: "); puts(itoh(proc_address)); putsv(" task id ", task_ID);
	remove_task(proc_address, task_ID);

	release_cluster_resources(cluster_id, 1);
}




/** Maps a task into a cluster processor. This function only selects the processor not modifying any management structure
 * The mapping heuristic is based on the processor's utilization (slack time) and the number of free_pages
 * \param task_id ID of the task to be mapped
 * \return Address of the selected processor
 */
int map_task(int task_id){

	int proc_address;
	int canditate_proc = -1;
	int max_slack_time = -1;
	int slack_time;

	//putsv("Mapping call for task id ", task_id);

#if MAX_STATIC_TASKS
	//Test if the task is statically mapped
	for(int i=0; i<MAX_STATIC_TASKS; i++){

		//Test if task_id is statically mapped
		if (static_map[i][0] == task_id){
			puts("Task id "); puts(itoa(static_map[i][0])); puts(" statically mapped at processor"); puts(itoh(static_map[i][1])); puts("\n");

			proc_address = static_map[i][1];

			if (get_proc_free_pages(proc_address) <= 0){
				puts("ERROR: Processor not have free resources\n");
				while(1);
			}

			return proc_address;
		}
	}
#endif


	//Else, map the task following a CPU utilization based algorithm
	for(int i=0; i<MAX_CLUSTER_SLAVES; i++){

		proc_address = get_proc_address(i);

		if (get_proc_free_pages(proc_address) > 0){

			slack_time = get_proc_slack_time(proc_address);

			if (max_slack_time < slack_time){
				canditate_proc = proc_address;
				max_slack_time = slack_time;
			}
		}
	}

	if (canditate_proc != -1){

		puts("Mapeam. para tarefa "), puts(itoa(task_id)); puts(" mapeada no processador "); puts(itoh(canditate_proc)); puts("\n");

		return canditate_proc;
	}

	putsv("WARNING: no resources available in cluster to map task ", task_id);
	return -1;


}





/**This heuristic maps all task of an application
 * Note that some task can not be mapped due the cluster is full or the processors not satisfies the
 * task requiriments. In this case, the reclustering will be used after the application_mapping funcion calling
 * into the kernel_master.c source file
 * Clearly the tasks that need reclustering are those one that have he allocated_processor equal to -1
 * \param cluster_id ID of the cluster where the application will be mapped
 * \param app_id ID of the application to be mapped
 * \return 1 if mapping OK, 0 if there are no available resources
*/
int application_mapping(int cluster_id, int app_id){      //==============================================ezequiel estou modificando aqui

	Application * app;
	app = get_application_ptr(app_id);
	Task *t;
	Task *tt;
	Dependence *dep;
		
	int proc_address;
	int tarefa_inicial; 
	int index = 1;    
	int ordem_map[app->tasks_number];
	int dep_tmp[(app->tasks_number) * (app->tasks_number)-1 ];
	int x_m;
	int y_m;
	int x_s;
	int y_s;
	int flit;
	

	for(int i=0; i<app->tasks_number; i++){ //inicializa ordem_map    
		ordem_map[i] = -1;
	}


	puts("\nApplication_mapping comecando:\n");   

	tarefa_inicial = app->id_task_inicial;              
	putsv("tarefa inicial da app: ", tarefa_inicial); 
	ordem_map[0]=tarefa_inicial;
	proc_address = ff(tarefa_inicial);  //514 ou outro para nn

	t = &app->tasks[tarefa_inicial];
	if (proc_address == -1){
		return 0;
	}else{
		t->allocated_proc = proc_address;
		page_used(cluster_id, proc_address, tarefa_inicial);
	}

	for(int i=0; i<app->tasks_number; i++){
		
		t = &app->tasks[ordem_map[i]];
		x_m = t->allocated_proc >> 8;
		y_m = t->allocated_proc & 0xFF;

		for(int j=0; j<t->dependences_number; j++){ //preenche o vetor de dependencias
			dep = &t->dependences[j];
			dep_tmp[j] = dep->task;		
		}
		
		for(int k=0; k<t->dependences_number; k++){ //procura se ja nao esta no ordem_map
			tt = &app->tasks[dep_tmp[k]];
			int count = 0;
			for(int l=0; l<app->tasks_number; l++){
				if( dep_tmp[k] == ordem_map[l] ){
					count = count +1;
				}
			}
			if(count==0){

				ordem_map[index]= dep_tmp[k];
				proc_address = pl(dep_tmp[k], x_m, y_m); //nn(dep_tmp[k],2,2);, 2x2 ou outro
				if (proc_address == -1){
					return 0;
				}else{
					tt->allocated_proc = proc_address;
					page_used(cluster_id, proc_address, dep_tmp[k]);
				}	
				index = index+1;
			}
			
			dep = &t->dependences[k];  //adicionando os pesos nos links
			flit = dep->flits;
			x_s = tt->allocated_proc >> 8;
			y_s = tt->allocated_proc & 0xFF;
			adicionarPeso(x_m, y_m, x_s, y_s, flit);

			//putsv(">>",dep->task);
			//putsv(">>",x_s);
			//putsv(">>",y_s);
			//puts("\n");
		}		
	}

	printLinkC();
	printLinkB();
	printLinkD();
	printLinkE();


	puts("A app tem todas suas tarefas mapeadas\n\n");

	return 1;
}

/**Selects a cluster to insert an application
 * \param GM_cluster_id cluster ID of the global manager processor
 * \param app_task_number Number of task of requered application
 * \return > 0 if mapping OK, -1 if there is not resources available
*/
int SearchCluster(int GM_cluster_id, int app_task_number) {

	int selected_cluster = -1;
	int freest_cluster = 0;

	for (int i=0; i<CLUSTER_NUMBER; i++){

		if (i == GM_cluster_id) continue;

		if (cluster_info[i].free_resources > freest_cluster){
			selected_cluster = i;
			freest_cluster = cluster_info[i].free_resources;
		}
	}

	if (cluster_info[GM_cluster_id].free_resources > freest_cluster){
		selected_cluster = GM_cluster_id;
	}

	return selected_cluster;
}

//======================================================================================ezequiel

int nn(int task_id, int x_Taskmestre, int y_Taskmestre){

	int proc_address;
	int canditate_proc = -1;
	

	//putsv("Mapping call for task id ", task_id);

#if MAX_STATIC_TASKS
	//Test if the task is statically mapped
	for(int i=0; i<MAX_STATIC_TASKS; i++){

		//Test if task_id is statically mapped
		if (static_map[i][0] == task_id){
			puts("Task id "); puts(itoa(static_map[i][0])); puts(" statically mapped at processor"); puts(itoh(static_map[i][1])); puts("\n");

			proc_address = static_map[i][1];

			if (get_proc_free_pages(proc_address) <= 0){
				puts("ERROR: Processor not have free resources\n");
				while(1);
			}

			return proc_address;
		}
	}
#endif



	int ROTX=XCLUSTER;   //X E Y DO CLUSTER, ESTAO NO ARQUIVO kernel_pkg.h
	int ROTY=YCLUSTER;
	
	int begin, end;
   	int primeiravez;
   	int esquerda, direita;

   	int XMASTER, YMASTER;
   	int z;
   	int tam;

   	int vetX[2][2*ROTX];
   	int vetY[2][2*ROTX];
   	int *sX;
   	int *sY;
   	int pt;
   	int *tX;
   	int *tY;
   	int *aX;
   	int *aY;
   	int tmpX, tmpY;

	XMASTER = x_Taskmestre;
   	YMASTER = y_Taskmestre;
   

   	vetX[0][0] = XMASTER;
   	vetY[0][0] = YMASTER;
   	sX = &vetX[0][0];
   	sY = &vetY[0][0];
   	tX = &vetX[1][0];
   	tY = &vetY[1][0];

   	primeiravez=1;
   	esquerda = 1;
   	direita = 1;;
   	tam = 0;
   	begin=1;
   	end=1;
	
	while(1){
	      	// INÍCIO QUANDO SÓ TEM O ENDEREÇO DO MESTRE NA FILA
		if(primeiravez){
			primeiravez=0;
		 	pt=0;
			if(sX[0]>0){           //verifica se tem alguem na esquerda
		    		tX[pt] = sX[0]-1;
		    		tY[pt] = sY[0];
		    		pt++;
			}
			else{
				esquerda = 0;
			}
			if(sY[0]<ROTY-1){     //verifica se tem alguem acima
		    		tX[pt] = sX[0];
		    		tY[pt] = sY[0]+1;
		    		pt++;
			}
			if(sY[0]>0){          //verifica se tem alguem abaixo
		    		tX[pt] = sX[0];
		    		tY[pt] = sY[0]-1;
		    		pt++;
		 	}
		 	if(sX[0]<ROTX-1){     //verifica se tem alguem a direita
		    		tX[pt] = sX[0]+1;
		    		tY[pt] = sY[0];
		    		pt++;
		 	}
		 	else{
		    		direita = 0;
		 	}
	      	}
	      	// RESTO DO COMPORTAMENTO;
	      	else{
		 	// PRIMEIRO CARA
		 	pt=0;
		 	if(esquerda){                //verifica se tem alguem na esquerda
		    		if(sX[0]>0){
		       			tX[pt] = sX[0]-1;tY[pt] = sY[0]; pt++;
		    		}
		    		else{
		       		esquerda = 0;
		    		}
		    		if(sY[0]<ROTY-1){         //verifica se tem alguem acima
		       			tX[pt] = sX[0]; tY[pt] = sY[0]+1; pt++;
		    		}
		    		if(sY[0]>0){              //verifica se tem alguem abaixo
		       			tX[pt] = sX[0]; tY[pt] = sY[0]-1; pt++;
		    		}
			}

		 	// PESSOAL DO MEIO
		 	for(z=begin; z<tam-end; z++){
		    		if((sY[z]>YMASTER)&&(sY[z]<ROTY-1)){
		       			tX[pt] = sX[z]; tY[pt] = sY[z]+1; pt++;
		    		}
		    		else{
		       			if((sY[z]<YMASTER)&&(sY[z]>0)){
		          			tX[pt] = sX[z]; tY[pt] = sY[z]-1; pt++;
		       			}
		       			else{
		         			if(sY[z]==YMASTER){
		             				tX[pt] = sX[z]; tY[pt] = sY[z]-1; pt++;
		             				tX[pt] = sX[z]; tY[pt] = sY[z]+1; pt++;
		          			}
		       			}
		    		}
		 	}

		 	// ÚLTIMO CARA
		 	if(direita){
		    		if(sY[tam-1]<ROTY-1){
		       			tX[pt] = sX[tam-1]; tY[pt] = sY[tam-1]+1; pt++;
		    		}
		    		if(sY[tam-1]>0){
		       			tX[pt] = sX[tam-1]; tY[pt] = sY[tam-1]-1; pt++;
		    		}
		    		if(sX[tam-1]<ROTX-1){
		       			tX[pt] = sX[tam-1]+1; tY[pt] = sY[tam-1]; pt++;
		    		}
		    		else{
		       			direita = 0;
		    		}
		 	}
	      	}

	      	begin = esquerda;
	      	end = direita;
	      	tam = pt;
	      	aX = tX;
	      	aY = tY;
	      	tX = sX;
	      	tY = sY;
	      	sX = aX;
	      	sY = aY;

	      	if(!tam){
			puts("ERRO SNN - Posicionador SNN não achou ninguém \n");
		 	return -1; //return -1
	      	}

	      	for(z=0; z<tam; z++){
			tmpX = aX[z];
			tmpY = aY[z];
		 	
		    	proc_address = tmpX*256 + tmpY;//Forms the proc address
		    
		    	if (get_proc_free_pages(proc_address) > 0){

				canditate_proc = proc_address;

				puts("Mapeam. para tarefa "), puts(itoa(task_id)); puts(" mapeada no processador "); puts(itoh(canditate_proc)); puts("\n");

				return canditate_proc; //retorna o endereço do processador selecionado
		 	}
	      	}
	}	

}

int ff(int task_id){

	int proc_address;
	int canditate_proc = -1;
	

	//putsv("Mapping call for task id ", task_id);

#if MAX_STATIC_TASKS
	//Test if the task is statically mapped
	for(int i=0; i<MAX_STATIC_TASKS; i++){

		//Test if task_id is statically mapped
		if (static_map[i][0] == task_id){
			puts("Task id "); puts(itoa(static_map[i][0])); puts(" statically mapped at processor"); puts(itoh(static_map[i][1])); puts("\n");

			proc_address = static_map[i][1];

			if (get_proc_free_pages(proc_address) <= 0){
				puts("ERROR: Processor not have free resources\n");
				while(1);
			}

			return proc_address;
		}
	}
#endif


	for(int i=0; i<MAX_CLUSTER_SLAVES; i++){

		proc_address = get_proc_address(i);

		if (get_proc_free_pages(proc_address) > 0){

			canditate_proc = proc_address;

			if (canditate_proc != -1){

				puts("Task mapping for task "), puts(itoa(task_id)); puts(" maped at proc "); puts(itoh(canditate_proc)); puts("\n");

				return canditate_proc;
			}

			putsv("WARNING: no resources available in cluster to map task ", task_id);
			return -1;
			
		}
	}
}
int pl(int task_id, int Xmestre, int Ymestre){    
	int proc_address;
	int canditate_proc = -1;
	int pesoTmp;
	int peso=999999;
	int x,y;
	

	for(int i=0; i<MAX_CLUSTER_SLAVES; i++){

		proc_address = get_proc_address(i);
		x = proc_address >> 8;
		y = proc_address & 0xFF;

		if (get_proc_free_pages(proc_address) > 0){

			pesoTmp = calcularPeso(Xmestre, Ymestre, x, y);
			putsv("PesoTmp:", pesoTmp);
            		if(pesoTmp < peso){
               			peso = pesoTmp;
				canditate_proc = proc_address;
            		}

			putsv("Xmestre:", Xmestre); putsv("Ymestre:", Ymestre);
			putsv("x:", x); putsv("y:", y);
			putsv("peso:", peso);
			puts("\n");
		}
	}	

	if (canditate_proc != -1){

		puts("Mappeam. tarefa "), puts(itoa(task_id)); puts(" maped no proc "); puts(itoh(canditate_proc)); puts("\n");

		return canditate_proc;
	}

	putsv("WARNING: no resources available in cluster to map task ", task_id);
	return -1;
			
}
