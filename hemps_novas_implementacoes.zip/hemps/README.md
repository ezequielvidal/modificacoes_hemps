# Hermes Multiprocessor System on Chip (HeMPS)

Site: http://www.inf.pucrs.br/hemps/

Plataforma de desenvolvimento em redes intrachip.
